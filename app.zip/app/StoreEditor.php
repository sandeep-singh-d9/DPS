<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StoreEditor extends Model
{
    protected $fillable = ['editor_data'];
}
